﻿using System.Diagnostics.Metrics;

namespace Harmonium.Models
{
    public class InstrumentUtilisateur
    {
        public int id_instrument {  get; set; }
        public int id_utilisateur { get; set; }
    }
}
